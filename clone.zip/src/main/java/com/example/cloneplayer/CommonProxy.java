package com.example.cloneplayer;

public class CommonProxy {
    public void preInit() {
    }

    public void init() {
    }
}