package com.example.cloneplayer;

import net.minecraftforge.common.config.Configuration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CloneConfig {
    private static Configuration config;

    public static int campRadius = 16;
    public static int patrolWait = 3;
    public static int chaseGraceTime = 2;
    public static boolean glowEyes = true;

    public static void init(File file) {
        config = new Configuration(file);
        sync();
    }

    public static void sync() {
        campRadius = config.getInt("camp_radius", "general", 16, 1, 256, "Camp mode radius");
        patrolWait = config.getInt("patrol_wait", "general", 3, 0, 3600, "Seconds to wait at patrol points");
        chaseGraceTime = config.getInt("chase_grace_time", "general", 2, 0, 60, "Seconds of grace after anti-cheese block breaking");
        glowEyes = config.getBoolean("glow_eyes", "general", true, "Night glow effect");

        if (config.hasChanged()) {
            config.save();
        }
    }

    public static boolean setValue(String key, String value) {
        try {
            switch (key.toLowerCase()) {
                case "camp_radius":
                    campRadius = Integer.parseInt(value);
                    config.get("general", "camp_radius", 16).set(campRadius);
                    break;
                case "patrol_wait":
                    patrolWait = Integer.parseInt(value);
                    config.get("general", "patrol_wait", 3).set(patrolWait);
                    break;
                case "chase_grace_time":
                    chaseGraceTime = Integer.parseInt(value);
                    config.get("general", "chase_grace_time", 2).set(chaseGraceTime);
                    break;
                case "glow_eyes":
                    glowEyes = Boolean.parseBoolean(value);
                    config.get("general", "glow_eyes", true).set(glowEyes);
                    break;
                default:
                    return false;
            }

            if (config.hasChanged()) {
                config.save();
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static List<String> listValues() {
        List<String> out = new ArrayList<>();
        out.add("camp_radius = " + campRadius);
        out.add("patrol_wait = " + patrolWait);
        out.add("chase_grace_time = " + chaseGraceTime);
        out.add("glow_eyes = " + glowEyes);
        return out;
    }
}