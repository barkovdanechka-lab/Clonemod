package com.example.cloneplayer;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class CloneCommands {
    public static void registerAll(FMLServerStartingEvent event) {
        event.registerServerCommand(new CmdClonePlayer());
        event.registerServerCommand(new CmdCloneCon());
        event.registerServerCommand(new CmdCloneList());
        event.registerServerCommand(new CmdCloneRemove());
        event.registerServerCommand(new CmdCloneRemoveAll());
        event.registerServerCommand(new CmdCloneTp());
        event.registerServerCommand(new CmdCloneTpHere());
        event.registerServerCommand(new CmdCloneInv());
        event.registerServerCommand(new CmdCloneRename());
        event.registerServerCommand(new CmdCloneIgnore());
        event.registerServerCommand(new CmdCloneConfig());
    }

    private static abstract class BaseOpCommand extends CommandBase {
        @Override
        public int getRequiredPermissionLevel() {
            return 2;
        }

        protected EntityClonePlayer getCloneOrThrow(MinecraftServer server, String id) throws CommandException {
            EntityClonePlayer clone = CloneUtils.findClone(server, id);
            if (clone == null) {
                throw new CommandException("Clone not found: " + id);
            }
            return clone;
        }

        protected EntityPlayerMP getPlayerSender(ICommandSender sender) throws CommandException {
            if (!(sender.getCommandSenderEntity() instanceof EntityPlayerMP)) {
                throw new CommandException("This command can only be used by a player.");
            }
            return (EntityPlayerMP) sender.getCommandSenderEntity();
        }

        protected String join(String[] args, int from) {
            StringBuilder sb = new StringBuilder();
            for (int i = from; i < args.length; i++) {
                if (i > from) {
                    sb.append(" ");
                }
                sb.append(args[i]);
            }
            return sb.toString();
        }

        protected String joinSet(Set<String> set) {
            StringBuilder sb = new StringBuilder();
            boolean first = true;
            for (String s : set) {
                if (!first) {
                    sb.append(", ");
                }
                first = false;
                sb.append(s);
            }
            return sb.toString();
        }
    }

    public static class CmdClonePlayer extends BaseOpCommand {
        @Override
        public String getName() {
            return "cloneplayer";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/cloneplayer <PlayerName>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 1) {
                throw new CommandException(getUsage(sender));
            }

            String playerName = args[0];
            BlockPos pos = sender.getPosition();
            WorldServer world = server.getWorld(sender.getEntityWorld().provider.getDimension());

            EntityClonePlayer clone = new EntityClonePlayer(world);
            clone.setPosition(pos.getX() + 1.5D, pos.getY(), pos.getZ() + 0.5D);

            EntityPlayerMP player = server.getPlayerList().getPlayerByUsername(playerName);
            if (player != null) {
                clone.copyFromPlayer(player);
            } else {
                clone.initOfflineClone(playerName);
            }

            world.spawnEntity(clone);
            world.spawnParticle(EnumParticleTypes.PORTAL, clone.posX, clone.posY + 1.0D, clone.posZ, 40, 0.4D, 0.8D, 0.4D, 0.2D);

            sender.sendMessage(new TextComponentString(
                    "Clone created: " + clone.getName() + " [id=" + clone.getEntityId() + "]"
            ));
        }
    }

    public static class CmdCloneCon extends BaseOpCommand {
        @Override
        public String getName() {
            return "clonecon";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/clonecon <Clone|id> <hunt|follow|guard|stay|patrol|camp|berserk|difficulty> [args...]";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 2) {
                throw new CommandException(getUsage(sender));
            }

            EntityClonePlayer clone = getCloneOrThrow(server, args[0]);
            String action = args[1].toLowerCase();

            switch (action) {
                case "hunt":
                case "follow":
                case "guard":
                    if (args.length < 3) {
                        throw new CommandException(getUsage(sender));
                    }
                    clone.setControlledPlayerName(args[2]);
                    clone.setMode(CloneMode.fromString(action));
                    sender.sendMessage(new TextComponentString(
                            "Clone " + clone.getName() + " -> " + clone.getMode() + " " + args[2]
                    ));
                    break;

                case "stay":
                    clone.setControlledPlayerName("");
                    clone.setMode(CloneMode.STAY);
                    sender.sendMessage(new TextComponentString("Clone stopped."));
                    break;

                case "patrol":
                    clone.setControlledPlayerName("");
                    clone.setMode(CloneMode.PATROL);

                    if (args.length > 2) {
                        Set<String> patrolTargets = new LinkedHashSet<String>();
                        for (int i = 2; i < args.length; i++) {
                            patrolTargets.add(args[i]);
                        }
                        clone.setPatrolAlertPlayers(patrolTargets);
                        sender.sendMessage(new TextComponentString(
                                "PATROL mode enabled. Alert targets: " + joinSet(patrolTargets) + ". Use Control Stick to set patrol points."
                        ));
                    } else {
                        clone.clearPatrolAlertPlayers();
                        sender.sendMessage(new TextComponentString(
                                "PATROL mode enabled. No alert targets. Use Control Stick to set patrol points."
                        ));
                    }
                    break;

                case "camp":
                    clone.setControlledPlayerName("");
                    clone.setMode(CloneMode.CAMP);
                    sender.sendMessage(new TextComponentString("CAMP mode enabled. Use Control Stick to set point."));
                    break;

                case "berserk":
                    clone.setControlledPlayerName("");
                    clone.setMode(CloneMode.BERSERK);
                    sender.sendMessage(new TextComponentString("BERSERK mode enabled."));
                    break;

                case "difficulty":
                    if (args.length < 3) {
                        throw new CommandException(getUsage(sender));
                    }

                    CloneDifficulty diff = CloneDifficulty.fromString(args[2]);
                    if (diff == null) {
                        throw new CommandException("Difficulty: easy, normal, hard");
                    }

                    clone.setDifficultyLevel(diff);
                    sender.sendMessage(new TextComponentString("Clone difficulty: " + diff.name()));
                    break;

                default:
                    throw new CommandException(getUsage(sender));
            }
        }
    }

    public static class CmdCloneList extends BaseOpCommand {
        @Override
        public String getName() {
            return "clonelist";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/clonelist";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
            List<EntityClonePlayer> clones = CloneUtils.getAllClones(server);

            if (clones.isEmpty()) {
                sender.sendMessage(new TextComponentString("No clones found."));
                return;
            }

            sender.sendMessage(new TextComponentString("Clone list:"));
            for (EntityClonePlayer clone : clones) {
                sender.sendMessage(new TextComponentString(
                        "[" + clone.getEntityId() + "] " + clone.getName()
                                + " | mode=" + clone.getMode()
                                + " | diff=" + clone.getDifficultyLevel()
                                + " | dim=" + clone.dimension
                                + " | xyz=" + (int) clone.posX + " " + (int) clone.posY + " " + (int) clone.posZ
                ));
            }
        }
    }

    public static class CmdCloneRemove extends BaseOpCommand {
        @Override
        public String getName() {
            return "cloneremove";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/cloneremove <Clone|id>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 1) {
                throw new CommandException(getUsage(sender));
            }

            EntityClonePlayer clone = getCloneOrThrow(server, args[0]);
            clone.setDead();
            sender.sendMessage(new TextComponentString("Clone removed."));
        }
    }

    public static class CmdCloneRemoveAll extends BaseOpCommand {
        @Override
        public String getName() {
            return "cloneremoveall";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/cloneremoveall";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
            int removed = 0;
            for (EntityClonePlayer clone : CloneUtils.getAllClones(server)) {
                clone.setDead();
                removed++;
            }
            sender.sendMessage(new TextComponentString("Removed clones: " + removed));
        }
    }

    public static class CmdCloneTp extends BaseOpCommand {
        @Override
        public String getName() {
            return "clonetp";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/clonetp <Clone|id>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 1) {
                throw new CommandException(getUsage(sender));
            }

            EntityPlayerMP player = getPlayerSender(sender);
            EntityClonePlayer clone = getCloneOrThrow(server, args[0]);

            if (player.dimension != clone.dimension) {
                throw new CommandException("This version supports teleport only in the same dimension.");
            }

            player.connection.setPlayerLocation(clone.posX, clone.posY, clone.posZ, clone.rotationYaw, clone.rotationPitch);
            sender.sendMessage(new TextComponentString("Teleported to clone."));
        }
    }

    public static class CmdCloneTpHere extends BaseOpCommand {
        @Override
        public String getName() {
            return "clonetphere";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/clonetphere <Clone|id>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 1) {
                throw new CommandException(getUsage(sender));
            }

            EntityPlayerMP player = getPlayerSender(sender);
            EntityClonePlayer clone = getCloneOrThrow(server, args[0]);

            if (player.dimension != clone.dimension) {
                throw new CommandException("This version supports teleport only in the same dimension.");
            }

            clone.setLocationAndAngles(player.posX, player.posY, player.posZ, player.rotationYaw, player.rotationPitch);
            clone.getNavigator().clearPath();

            sender.sendMessage(new TextComponentString("Clone teleported to you."));
        }
    }

    public static class CmdCloneInv extends BaseOpCommand {
        @Override
        public String getName() {
            return "cloneinv";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/cloneinv <Clone|id>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 1) {
                throw new CommandException(getUsage(sender));
            }

            EntityPlayerMP player = getPlayerSender(sender);
            EntityClonePlayer clone = getCloneOrThrow(server, args[0]);

            if (player.dimension != clone.dimension) {
                throw new CommandException("Inventory GUI works only in the same dimension.");
            }

            player.openGui(ClonePlayerMod.INSTANCE, CloneGuiHandler.GUI_CLONE_INV, player.world, clone.getEntityId(), 0, 0);
        }
    }

    public static class CmdCloneRename extends BaseOpCommand {
        @Override
        public String getName() {
            return "clonerename";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/clonerename <Clone|id> <NewName>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 2) {
                throw new CommandException(getUsage(sender));
            }

            EntityClonePlayer clone = getCloneOrThrow(server, args[0]);
            String newName = join(args, 1);
            clone.setCloneName(newName);

            sender.sendMessage(new TextComponentString("Clone renamed to: " + newName));
        }
    }

    public static class CmdCloneIgnore extends BaseOpCommand {
        @Override
        public String getName() {
            return "cloneignore";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/cloneignore <Clone|id|all> <Player>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length < 2) {
                throw new CommandException(getUsage(sender));
            }

            String scope = args[0];
            String playerName = args[1];

            if ("all".equalsIgnoreCase(scope)) {
                boolean added = CloneWorldData.get(server.getWorld(0)).toggleGlobalIgnore(playerName);

                if (added) {
                    for (EntityClonePlayer clone : CloneUtils.getAllClones(server)) {
                        if (clone.isTargetingName(playerName)) {
                            clone.setMode(CloneMode.STAY);
                            clone.setControlledPlayerName("");
                        }
                    }
                }

                sender.sendMessage(new TextComponentString(
                        (added ? "Global ignore added for " : "Global ignore removed for ") + playerName
                ));
                return;
            }

            EntityClonePlayer clone = getCloneOrThrow(server, scope);
            boolean added = clone.toggleIgnore(playerName);

            sender.sendMessage(new TextComponentString(
                    (added ? "Ignore added for " : "Ignore removed for ") + playerName + " on clone " + clone.getName()
            ));
        }
    }

    public static class CmdCloneConfig extends BaseOpCommand {
        @Override
        public String getName() {
            return "cloneconfig";
        }

        @Override
        public String getUsage(ICommandSender sender) {
            return "/cloneconfig list | /cloneconfig <key> <value>";
        }

        @Override
        public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
            if (args.length == 0 || "list".equalsIgnoreCase(args[0])) {
                sender.sendMessage(new TextComponentString("ClonePlayer config:"));
                for (String line : CloneConfig.listValues()) {
                    sender.sendMessage(new TextComponentString("- " + line));
                }
                return;
            }

            if (args.length < 2) {
                throw new CommandException(getUsage(sender));
            }

            boolean ok = CloneConfig.setValue(args[0], args[1]);
            if (!ok) {
                throw new CommandException("Failed to change config value.");
            }

            sender.sendMessage(new TextComponentString("Config updated: " + args[0] + " = " + args[1]));
        }
    }
}