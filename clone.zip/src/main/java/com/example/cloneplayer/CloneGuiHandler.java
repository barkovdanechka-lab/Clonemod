package com.example.cloneplayer;

import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class CloneGuiHandler implements IGuiHandler {
    public static final int GUI_CLONE_INV = 1;

    @Override
    public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        if (id == GUI_CLONE_INV) {
            Entity entity = world.getEntityByID(x);
            if (entity instanceof EntityClonePlayer) {
                return new ContainerChest(player.inventory, (IInventory) entity, player);
            }
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        if (id == GUI_CLONE_INV) {
            Entity entity = world.getEntityByID(x);
            if (entity instanceof EntityClonePlayer) {
                return new GuiChest(player.inventory, (IInventory) entity);
            }
        }
        return null;
    }
}