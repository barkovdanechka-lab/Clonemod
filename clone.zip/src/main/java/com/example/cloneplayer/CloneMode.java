package com.example.cloneplayer;

public enum CloneMode {
    STAY,
    FOLLOW,
    GUARD,
    HUNT,
    PATROL,
    CAMP,
    BERSERK;

    public static CloneMode fromString(String s) {
        for (CloneMode mode : values()) {
            if (mode.name().equalsIgnoreCase(s)) {
                return mode;
            }
        }
        return null;
    }
}