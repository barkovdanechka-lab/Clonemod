package com.example.cloneplayer;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.EntityRegistry;

@Mod(modid = ClonePlayerMod.MODID, name = ClonePlayerMod.NAME, version = ClonePlayerMod.VERSION)
@Mod.EventBusSubscriber(modid = ClonePlayerMod.MODID)
public class ClonePlayerMod {
    public static final String MODID = "cloneplayer";
    public static final String NAME = "Clone Player Mod";
    public static final String VERSION = "1.0.0";

    @Instance(MODID)
    public static ClonePlayerMod INSTANCE;

    @SidedProxy(clientSide = "com.example.cloneplayer.ClientProxy", serverSide = "com.example.cloneplayer.CommonProxy")
    public static CommonProxy PROXY;

    public static final Item CONTROL_STICK = new ItemControlStick()
            .setRegistryName(new ResourceLocation(MODID, "control_stick"))
            .setUnlocalizedName(MODID + ".control_stick")
            .setCreativeTab(CreativeTabs.TOOLS);

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        CloneConfig.init(event.getSuggestedConfigurationFile());

        EntityRegistry.registerModEntity(
                new ResourceLocation(MODID, "clone_entity"),
                EntityClonePlayer.class,
                "clone_entity",
                1,
                this,
                64,
                1,
                true
        );

        NetworkRegistry.INSTANCE.registerGuiHandler(this, new CloneGuiHandler());
        PROXY.preInit();

        MinecraftForge.EVENT_BUS.register(this);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        PROXY.init();
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        CloneCommands.registerAll(event);
    }

    @SubscribeEvent
    public static void onRegisterItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(CONTROL_STICK);
    }
}