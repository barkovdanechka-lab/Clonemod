package com.example.cloneplayer;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.SkinManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class RenderClonePlayer extends RenderLiving<EntityClonePlayer> {
    private static final Map<String, ResourceLocation> SKIN_CACHE = new HashMap<String, ResourceLocation>();
    private static final Set<String> REQUESTED = new HashSet<String>();

    public RenderClonePlayer(RenderManager rendermanagerIn) {
        super(rendermanagerIn, new ModelPlayer(0.0F, false), 0.5F);

        this.addLayer(new LayerHeldItem(this));
        this.addLayer(new LayerBipedArmor(this) {
            @Override
            protected void initArmor() {
                this.modelLeggings = new ModelBiped(0.5F);
                this.modelArmor = new ModelBiped(1.0F);
            }
        });
    }

    private void setModelState(EntityClonePlayer entity) {
        ModelPlayer model = (ModelPlayer) this.getMainModel();
        model.setVisible(true);
        model.isSneak = entity.isSneaking();
        model.rightArmPose = ModelBiped.ArmPose.EMPTY;
        model.leftArmPose = ModelBiped.ArmPose.EMPTY;

        ItemStack mainHand = entity.getHeldItemMainhand();
        ItemStack offHand = entity.getHeldItemOffhand();

        ModelBiped.ArmPose rightPose = ModelBiped.ArmPose.EMPTY;
        ModelBiped.ArmPose leftPose = ModelBiped.ArmPose.EMPTY;

        if (!mainHand.isEmpty()) {
            rightPose = ModelBiped.ArmPose.ITEM;
        }

        if (!offHand.isEmpty()) {
            leftPose = ModelBiped.ArmPose.ITEM;
        }

        if (entity.getItemInUseCount() > 0) {
            EnumHand activeHand = entity.getActiveHand();
            ItemStack activeStack = entity.getActiveItemStack();

            if (!activeStack.isEmpty()) {
                EnumAction action = activeStack.getItemUseAction();

                if (action == EnumAction.BLOCK) {
                    if (activeHand == EnumHand.MAIN_HAND) {
                        rightPose = ModelBiped.ArmPose.BLOCK;
                    } else {
                        leftPose = ModelBiped.ArmPose.BLOCK;
                    }
                } else if (action == EnumAction.BOW) {
                    if (activeHand == EnumHand.MAIN_HAND) {
                        rightPose = ModelBiped.ArmPose.BOW_AND_ARROW;
                    } else {
                        leftPose = ModelBiped.ArmPose.BOW_AND_ARROW;
                    }
                }
            }
        }

        if (entity.getPrimaryHand() == EnumHandSide.RIGHT) {
            model.rightArmPose = rightPose;
            model.leftArmPose = leftPose;
        } else {
            model.rightArmPose = leftPose;
            model.leftArmPose = rightPose;
        }
    }

    private void requestSkin(final String name) {
        final String key = name.toLowerCase();

        if (REQUESTED.contains(key)) {
            return;
        }

        REQUESTED.add(key);

        Minecraft.getMinecraft().addScheduledTask(new Runnable() {
            @Override
            public void run() {
                GameProfile profile = new GameProfile(null, name);
                profile = TileEntitySkull.updateGameprofile(profile);

                if (profile == null) {
                    return;
                }

                Minecraft.getMinecraft().getSkinManager().loadProfileTextures(profile, new SkinManager.SkinAvailableCallback() {
                    @Override
                    public void skinAvailable(MinecraftProfileTexture.Type type, ResourceLocation location, MinecraftProfileTexture profileTexture) {
                        if (type == MinecraftProfileTexture.Type.SKIN) {
                            SKIN_CACHE.put(key, location);
                        }
                    }
                }, true);
            }
        });
    }

    @Override
    public void doRender(EntityClonePlayer entity, double x, double y, double z, float entityYaw, float partialTicks) {
        setModelState(entity);
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityClonePlayer entity) {
        String name = entity.getSkinSourceName();
        if (name != null && !name.isEmpty()) {
            String key = name.toLowerCase();

            ResourceLocation cached = SKIN_CACHE.get(key);
            if (cached != null) {
                return cached;
            }

            ResourceLocation vanillaSkin = AbstractClientPlayer.getLocationSkin(name);
            AbstractClientPlayer.getDownloadImageSkin(vanillaSkin, name);
            requestSkin(name);

            return vanillaSkin != null
                    ? vanillaSkin
                    : DefaultPlayerSkin.getDefaultSkin(EntityPlayer.getUUID(new GameProfile(null, name)));
        }

        return DefaultPlayerSkin.getDefaultSkinLegacy();
    }
}