package com.example.cloneplayer;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBreakDoor;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArrow;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.Path;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.potion.PotionEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class EntityClonePlayer extends EntityCreature implements IRangedAttackMob, IInventory {
    private static final DataParameter<String> SKIN_SOURCE =
            EntityDataManager.createKey(EntityClonePlayer.class, DataSerializers.STRING);

    private final NonNullList<ItemStack> cloneInventory = NonNullList.withSize(45, ItemStack.EMPTY);
    private final Set<String> ignoredPlayers = new HashSet<String>();
    private final Set<String> patrolAlertPlayers = new HashSet<String>();

    private CloneMode mode = CloneMode.STAY;
    private CloneDifficulty difficulty = CloneDifficulty.NORMAL;
    private String controlledPlayerName = "";

    private BlockPos patrolA;
    private BlockPos patrolB;
    private boolean patrolToA = true;
    private int patrolWaitTicks = 0;

    private BlockPos campPos;

    private int meleeCooldown = 0;
    private int rangedCooldown = 0;
    private int bowChargeTicks = 0;
    private int foodCooldown = 0;

    private boolean diggingInvulnerable = false;
    private BlockPos breakingPos = null;
    private int breakingTicks = 0;
    private int chaseGraceTicks = 0;

    public EntityClonePlayer(World worldIn) {
        super(worldIn);
        setSize(0.6F, 1.8F);
        enablePersistence();
        experienceValue = 0;

        if (getNavigator() instanceof PathNavigateGround) {
            PathNavigateGround nav = (PathNavigateGround) getNavigator();
            nav.setCanSwim(true);
            nav.setEnterDoors(true);
            nav.setBreakDoors(true);
        }
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(SKIN_SOURCE, "");
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(1, new EntityAIBreakDoor(this));
        tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(9, new EntityAILookIdle(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();

        if (getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE) == null) {
            getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
        }

        if (getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE) == null) {
            getAttributeMap().registerAttribute(SharedMonsterAttributes.FOLLOW_RANGE);
        }

        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.23D);
        getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(1.0D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(48.0D);
    }

    public void setSkinSourceName(String name) {
        dataManager.set(SKIN_SOURCE, name == null ? "" : name);
    }

    public String getSkinSourceName() {
        return dataManager.get(SKIN_SOURCE);
    }

    public void setCloneName(String name) {
        setCustomNameTag(name);
        setAlwaysRenderNameTag(true);
    }

    public CloneMode getMode() {
        return mode;
    }

    public CloneDifficulty getDifficultyLevel() {
        return difficulty;
    }

    public String getControlledPlayerName() {
        return controlledPlayerName;
    }

    public void setMode(CloneMode mode) {
        this.mode = mode == null ? CloneMode.STAY : mode;
        stopBowUse();
        setAttackTarget(null);
        getNavigator().clearPath();
    }

    public void setControlledPlayerName(String name) {
        this.controlledPlayerName = name == null ? "" : name;
        if (isIgnoredPlayer(this.controlledPlayerName)) {
            setMode(CloneMode.STAY);
            this.controlledPlayerName = "";
        }
    }

    public void setDifficultyLevel(CloneDifficulty difficulty) {
        this.difficulty = difficulty == null ? CloneDifficulty.NORMAL : difficulty;
        applyDifficultyStats();
    }

    public void setPatrolAlertPlayers(Set<String> names) {
        patrolAlertPlayers.clear();
        if (names == null) {
            return;
        }

        for (String s : names) {
            if (s != null && !s.trim().isEmpty()) {
                patrolAlertPlayers.add(s.toLowerCase());
            }
        }
    }

    public void clearPatrolAlertPlayers() {
        patrolAlertPlayers.clear();
    }

    private void applyDifficultyStats() {
        if (difficulty == null) {
            difficulty = CloneDifficulty.NORMAL;
        }

        if (getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED) != null) {
            getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(difficulty.getAttributeSpeed());
        }

        setAIMoveSpeed((float) difficulty.getAttributeSpeed());
    }

    public void setPatrolPoints(BlockPos a, BlockPos b) {
        this.patrolA = a;
        this.patrolB = b;
        this.patrolToA = true;
        this.patrolWaitTicks = 0;
        this.mode = CloneMode.PATROL;
        this.controlledPlayerName = "";
        stopBowUse();
        setAttackTarget(null);
    }

    public void setCampPosition(BlockPos pos) {
        this.campPos = pos;
        this.mode = CloneMode.CAMP;
        this.controlledPlayerName = "";
        stopBowUse();
        setAttackTarget(null);
    }

    public boolean toggleIgnore(String playerName) {
        String key = playerName.toLowerCase();
        boolean added;

        if (ignoredPlayers.contains(key)) {
            ignoredPlayers.remove(key);
            added = false;
        } else {
            ignoredPlayers.add(key);
            added = true;
        }

        if (added && playerName.equalsIgnoreCase(controlledPlayerName)) {
            setMode(CloneMode.STAY);
            setControlledPlayerName("");
        }

        return added;
    }

    public boolean isIgnoredPlayer(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }

        if (ignoredPlayers.contains(name.toLowerCase())) {
            return true;
        }

        if (world != null && world.getMinecraftServer() != null) {
            return CloneWorldData.get(world.getMinecraftServer().getWorld(0)).isGloballyIgnored(name);
        }

        return false;
    }

    public boolean isTargetingName(String name) {
        return name != null && name.equalsIgnoreCase(controlledPlayerName);
    }

    public void copyFromPlayer(EntityPlayerMP player) {
        setCloneName(player.getName());
        setSkinSourceName(player.getName());
        setHealth(Math.min(player.getHealth(), getMaxHealth()));

        for (int i = 0; i < 36; i++) {
            cloneInventory.set(i, player.inventory.mainInventory.get(i).copy());
        }

        for (int i = 0; i < 4; i++) {
            cloneInventory.set(36 + i, player.inventory.armorInventory.get(i).copy());
        }

        cloneInventory.set(40, player.inventory.offHandInventory.get(0).copy());

        setItemStackToSlot(EntityEquipmentSlot.MAINHAND, player.getHeldItemMainhand().copy());
        syncEquipmentFromInventory();
        applyDifficultyStats();
    }

    public void initOfflineClone(String playerName) {
        setCloneName(playerName);
        setSkinSourceName(playerName);
        setHealth(getMaxHealth());
        applyDifficultyStats();
    }

    private void syncEquipmentFromInventory() {
        setItemStackToSlot(EntityEquipmentSlot.FEET, cloneInventory.get(36));
        setItemStackToSlot(EntityEquipmentSlot.LEGS, cloneInventory.get(37));
        setItemStackToSlot(EntityEquipmentSlot.CHEST, cloneInventory.get(38));
        setItemStackToSlot(EntityEquipmentSlot.HEAD, cloneInventory.get(39));
        setItemStackToSlot(EntityEquipmentSlot.OFFHAND, cloneInventory.get(40));
    }

    private EntityPlayerMP resolveControlledPlayer() {
        MinecraftServer server = world.getMinecraftServer();
        if (server == null || controlledPlayerName == null || controlledPlayerName.isEmpty()) {
            return null;
        }
        return server.getPlayerList().getPlayerByUsername(controlledPlayerName);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        if (world.isRemote) {
            return;
        }

        syncEquipmentFromInventory();
        applyDifficultyStats();
        setGlowing(CloneConfig.glowEyes && !world.isDaytime());

        if (meleeCooldown > 0) meleeCooldown--;
        if (rangedCooldown > 0) rangedCooldown--;
        if (foodCooldown > 0) foodCooldown--;

        if (chaseGraceTicks > 0) {
            chaseGraceTicks--;
            stopBowUse();
            getNavigator().clearPath();
            setAttackTarget(null);

            if (chaseGraceTicks <= 0) {
                diggingInvulnerable = false;
            }
            return;
        }

        if (breakingPos != null) {
            stopBowUse();
            updateBreakingLogic();
            return;
        }

        handleFoodUse();
        handleBehavior();
        handleCombat();
    }

    private void handleBehavior() {
        switch (mode) {
            case STAY:
                stopBowUse();
                getNavigator().clearPath();
                setAttackTarget(null);
                break;

            case FOLLOW: {
                EntityPlayerMP player = resolveControlledPlayer();
                if (player == null || isIgnoredPlayer(player.getName())) {
                    stopBowUse();
                    getNavigator().clearPath();
                    setAttackTarget(null);
                    return;
                }

                setAttackTarget(null);

                if (getDistance(player) > 3.0D) {
                    getNavigator().tryMoveToEntityLiving(player, difficulty.getMoveSpeed());
                } else {
                    getNavigator().clearPath();
                }
                break;
            }

            case GUARD: {
                EntityPlayerMP player = resolveControlledPlayer();
                if (player == null || isIgnoredPlayer(player.getName())) {
                    stopBowUse();
                    getNavigator().clearPath();
                    setAttackTarget(null);
                    return;
                }

                if (getDistance(player) > 3.0D) {
                    getNavigator().tryMoveToEntityLiving(player, difficulty.getMoveSpeed());
                } else if (getAttackTarget() == null) {
                    getNavigator().clearPath();
                }

                EntityLivingBase revenge = player.getRevengeTarget();
                if (revenge != null && revenge.isEntityAlive() && !(revenge instanceof EntityClonePlayer)) {
                    if (revenge instanceof EntityPlayer) {
                        if (!isIgnoredPlayer(revenge.getName())) {
                            setAttackTarget(revenge);
                        }
                    } else {
                        setAttackTarget(revenge);
                    }
                }
                break;
            }

            case HUNT: {
                EntityPlayerMP player = resolveControlledPlayer();
                if (player == null || isIgnoredPlayer(player.getName())) {
                    setMode(CloneMode.STAY);
                    setControlledPlayerName("");
                    return;
                }
                setAttackTarget(player);
                break;
            }

            case PATROL:
                updatePatrolMode();
                break;

            case CAMP:
                updateCamp();
                break;

            case BERSERK:
                updateBerserkMode();
                break;
        }
    }

    private void updatePatrolMode() {
        EntityLivingBase current = getAttackTarget();
        if (current != null && isValidPatrolTarget(current)) {
            return;
        }

        EntityPlayer target = findPatrolAlertTarget();
        if (target != null) {
            setAttackTarget(target);
            return;
        }

        stopBowUse();
        setAttackTarget(null);

        if (patrolA == null || patrolB == null) {
            getNavigator().clearPath();
            return;
        }

        if (patrolWaitTicks > 0) {
            patrolWaitTicks--;
            getNavigator().clearPath();
            return;
        }

        BlockPos targetPos = patrolToA ? patrolA : patrolB;
        double dist = distanceSqToCenter(targetPos);

        if (dist <= 2.0D) {
            patrolToA = !patrolToA;
            patrolWaitTicks = CloneConfig.patrolWait * 20;
            getNavigator().clearPath();
            return;
        }

        getNavigator().tryMoveToXYZ(targetPos.getX() + 0.5D, targetPos.getY(), targetPos.getZ() + 0.5D, difficulty.getMoveSpeed());
    }

    private boolean isValidPatrolTarget(EntityLivingBase target) {
        if (target == null || !target.isEntityAlive()) {
            return false;
        }

        if (!(target instanceof EntityPlayer)) {
            return false;
        }

        EntityPlayer player = (EntityPlayer) target;
        return patrolAlertPlayers.contains(player.getName().toLowerCase()) && !isIgnoredPlayer(player.getName());
    }

    private EntityPlayer findPatrolAlertTarget() {
        if (patrolAlertPlayers.isEmpty()) {
            return null;
        }

        EntityPlayer best = null;
        double bestDist = Double.MAX_VALUE;
        double range = getFollowRange();

        for (EntityPlayer player : world.playerEntities) {
            if (player == null || !player.isEntityAlive() || player.capabilities.disableDamage) {
                continue;
            }

            if (isIgnoredPlayer(player.getName())) {
                continue;
            }

            if (!patrolAlertPlayers.contains(player.getName().toLowerCase())) {
                continue;
            }

            double dist = getDistance(player);
            if (dist > range) {
                continue;
            }

            if (!isInFieldOfView(player, 120.0D)) {
                continue;
            }

            if (!hasStrictLineOfSight(player)) {
                continue;
            }

            if (dist < bestDist) {
                bestDist = dist;
                best = player;
            }
        }

        return best;
    }

    private void updateCamp() {
        if (campPos == null) {
            stopBowUse();
            getNavigator().clearPath();
            return;
        }

        double dist = distanceSqToCenter(campPos);
        if (dist > 2.5D) {
            stopBowUse();
            getNavigator().tryMoveToXYZ(campPos.getX() + 0.5D, campPos.getY(), campPos.getZ() + 0.5D, difficulty.getMoveSpeed());
            setAttackTarget(null);
            return;
        }

        getNavigator().clearPath();

        EntityLivingBase target = findCampTarget();
        if (target != null) {
            setAttackTarget(target);
        } else {
            stopBowUse();
            setAttackTarget(null);
        }
    }

    private EntityLivingBase findCampTarget() {
        double radius = CloneConfig.campRadius;
        List<EntityLivingBase> entities = world.getEntitiesWithinAABB(
                EntityLivingBase.class,
                getEntityBoundingBox().grow(radius, radius / 2.0D, radius)
        );

        EntityLivingBase best = null;
        double bestDist = Double.MAX_VALUE;

        for (EntityLivingBase entity : entities) {
            if (entity == null || entity == this || !entity.isEntityAlive()) {
                continue;
            }

            if (entity instanceof EntityClonePlayer) {
                continue;
            }

            if (entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer) entity;
                if (player.capabilities.disableDamage) {
                    continue;
                }
                if (isIgnoredPlayer(player.getName())) {
                    continue;
                }
            }

            double dist = getDistance(entity);
            if (dist > radius) {
                continue;
            }

            if (!isInFieldOfView(entity, 120.0D)) {
                continue;
            }

            if (!hasStrictLineOfSight(entity)) {
                continue;
            }

            if (dist < bestDist) {
                bestDist = dist;
                best = entity;
            }
        }

        return best;
    }

    private void updateBerserkMode() {
        EntityLivingBase current = getAttackTarget();
        if (current != null && current.isEntityAlive()) {
            if (current instanceof EntityPlayer && ((EntityPlayer) current).capabilities.disableDamage) {
                setAttackTarget(null);
            } else if (current instanceof EntityPlayer && isIgnoredPlayer(current.getName())) {
                setAttackTarget(null);
            } else if (current == this) {
                setAttackTarget(null);
            } else {
                return;
            }
        }

        EntityLivingBase target = findBerserkTarget();
        if (target != null) {
            setAttackTarget(target);
        } else {
            stopBowUse();
            getNavigator().clearPath();
            setAttackTarget(null);
        }
    }

    private EntityLivingBase findBerserkTarget() {
        double range = getFollowRange();
        List<EntityLivingBase> entities = world.getEntitiesWithinAABB(
                EntityLivingBase.class,
                getEntityBoundingBox().grow(range, range / 2.0D, range)
        );

        EntityLivingBase best = null;
        double bestDist = Double.MAX_VALUE;

        for (EntityLivingBase entity : entities) {
            if (entity == null || entity == this || !entity.isEntityAlive()) {
                continue;
            }

            if (entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer) entity;
                if (player.capabilities.disableDamage) {
                    continue;
                }
                if (isIgnoredPlayer(player.getName())) {
                    continue;
                }
            }

            double dist = getDistance(entity);
            if (dist > range) {
                continue;
            }

            if (!isInFieldOfView(entity, 120.0D)) {
                continue;
            }

            if (!hasStrictLineOfSight(entity)) {
                continue;
            }

            if (dist < bestDist) {
                bestDist = dist;
                best = entity;
            }
        }

        return best;
    }

    private boolean isInFieldOfView(Entity entity, double fovDeg) {
        Vec3d look = getLookVec().normalize();
        Vec3d toTarget = entity.getPositionVector().subtract(getPositionVector()).normalize();
        double dot = MathHelper.clamp(look.dotProduct(toTarget), -1.0D, 1.0D);
        double angle = Math.toDegrees(Math.acos(dot));
        return angle <= (fovDeg / 2.0D);
    }

    private boolean hasStrictLineOfSight(Entity entity) {
        Vec3d start = new Vec3d(this.posX, this.posY + this.getEyeHeight(), this.posZ);
        double targetEye = entity instanceof EntityLivingBase
                ? ((EntityLivingBase) entity).posY + ((EntityLivingBase) entity).getEyeHeight()
                : entity.posY + entity.height * 0.85D;
        Vec3d end = new Vec3d(entity.posX, targetEye, entity.posZ);

        RayTraceResult result = world.rayTraceBlocks(start, end, false, false, false);
        return result == null || result.typeOfHit != RayTraceResult.Type.BLOCK;
    }

    private double distanceSqToCenter(BlockPos pos) {
        double dx = pos.getX() + 0.5D - this.posX;
        double dy = pos.getY() + 0.5D - this.posY;
        double dz = pos.getZ() + 0.5D - this.posZ;
        return dx * dx + dy * dy + dz * dz;
    }

    private double getFollowRange() {
        return getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE) != null
                ? getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).getAttributeValue()
                : 48.0D;
    }

    private void stopBowUse() {
        if (isHandActive()) {
            resetActiveHand();
        }
        bowChargeTicks = 0;
    }

    private float getHeldAttackDamage() {
        ItemStack held = getHeldItemMainhand();

        if (held.isEmpty()) {
            return 1.0F;
        }

        double damage = 0.0D;

        for (Map.Entry<String, AttributeModifier> entry : held.getAttributeModifiers(EntityEquipmentSlot.MAINHAND).entries()) {
            if (SharedMonsterAttributes.ATTACK_DAMAGE.getName().equals(entry.getKey())) {
                damage += entry.getValue().getAmount();
            }
        }

        if (damage <= 0.0D) {
            return 1.0F;
        }

        return (float) damage;
    }

    private void handleCombat() {
        EntityLivingBase target = getAttackTarget();
        if (target == null || !target.isEntityAlive()) {
            stopBowUse();
            return;
        }

        if (target == this) {
            stopBowUse();
            setAttackTarget(null);
            return;
        }

        if (target instanceof EntityClonePlayer && mode != CloneMode.BERSERK) {
            stopBowUse();
            setAttackTarget(null);
            return;
        }

        if (target instanceof EntityPlayer && isIgnoredPlayer(target.getName())) {
            stopBowUse();
            setAttackTarget(null);
            if (mode == CloneMode.HUNT) {
                setMode(CloneMode.STAY);
                setControlledPlayerName("");
            }
            return;
        }

        if (target instanceof EntityPlayer && shouldStartAntiCheese((EntityPlayer) target)) {
            stopBowUse();
            startBreakingSupport((EntityPlayer) target);
            return;
        }

        getLookHelper().setLookPositionWithEntity(target, 30.0F, 30.0F);

        boolean ranged = hasBowAndArrow() && getDistanceSq(target) > 36.0D;

        if (ranged) {
            equipBow();

            boolean canSee = hasStrictLineOfSight(target);
            double distSq = getDistanceSq(target);

            if (!canSee || distSq > 196.0D) {
                stopBowUse();
                getNavigator().tryMoveToEntityLiving(target, difficulty.getMoveSpeed());
                return;
            }

            getNavigator().clearPath();

            if (!isHandActive()) {
                setActiveHand(EnumHand.MAIN_HAND);
                bowChargeTicks = 0;
                return;
            }

            bowChargeTicks++;

            if (bowChargeTicks >= 20 && rangedCooldown <= 0) {
                float charge = ItemBow.getArrowVelocity(bowChargeTicks);
                stopBowUse();
                attackEntityWithRangedAttack(target, charge);
                rangedCooldown = difficulty.getRangedCooldown();
            }
        } else {
            stopBowUse();
            equipBestMelee();
            getNavigator().tryMoveToEntityLiving(target, difficulty.getMoveSpeed());

            if (getDistanceSq(target) <= 6.25D && meleeCooldown <= 0) {
                swingArm(EnumHand.MAIN_HAND);
                attackEntityAsMob(target);
                meleeCooldown = difficulty.getMeleeCooldown();
            }
        }
    }

    private boolean shouldStartAntiCheese(EntityPlayer player) {
        if (hasBowAndArrow()) {
            return false;
        }

        double dx = player.posX - posX;
        double dz = player.posZ - posZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        if (horizontal > 3.0D) {
            return false;
        }

        if (player.posY - posY < 2.5D) {
            return false;
        }

        Path path = getNavigator().getPathToEntityLiving(player);
        return path == null;
    }

    private void startBreakingSupport(EntityPlayer player) {
        BlockPos support = new BlockPos(player.posX, player.getEntityBoundingBox().minY - 0.01D, player.posZ);
        if (world.isAirBlock(support)) {
            support = support.down();
        }

        breakingPos = support;
        breakingTicks = 0;
        diggingInvulnerable = true;
        getNavigator().clearPath();
        setAttackTarget(null);
    }

    private void updateBreakingLogic() {
        if (breakingPos == null) {
            return;
        }

        if (world.isAirBlock(breakingPos)) {
            world.sendBlockBreakProgress(getEntityId(), breakingPos, -1);
            breakingPos = null;
            breakingTicks = 0;
            chaseGraceTicks = CloneConfig.chaseGraceTime * 20;
            return;
        }

        breakingTicks++;
        int progress = Math.min(9, (int) ((breakingTicks / 20.0F) * 10.0F));
        world.sendBlockBreakProgress(getEntityId(), breakingPos, progress);

        getLookHelper().setLookPosition(
                breakingPos.getX() + 0.5D,
                breakingPos.getY() + 0.5D,
                breakingPos.getZ() + 0.5D,
                20.0F,
                20.0F
        );

        if (breakingTicks >= 20) {
            IBlockState state = world.getBlockState(breakingPos);
            world.playEvent(2001, breakingPos, Block.getStateId(state));
            world.setBlockToAir(breakingPos);
            world.sendBlockBreakProgress(getEntityId(), breakingPos, -1);
            breakingPos = null;
            breakingTicks = 0;
            chaseGraceTicks = CloneConfig.chaseGraceTime * 20;
        }
    }

    private void handleFoodUse() {
        if (foodCooldown > 0 || getHealth() > 8.0F) {
            return;
        }

        for (int i = 0; i < 41; i++) {
            ItemStack stack = cloneInventory.get(i);
            if (!stack.isEmpty() && stack.getItem() instanceof ItemFood) {
                stack.shrink(1);
                heal(4.0F);
                foodCooldown = 60;
                return;
            }
        }
    }

    private boolean hasBowAndArrow() {
        return findItemSlot(Items.BOW) >= 0 && findArrowSlot() >= 0;
    }

    private void equipBow() {
        int bowSlot = findItemSlot(Items.BOW);
        if (bowSlot >= 0) {
            setItemStackToSlot(EntityEquipmentSlot.MAINHAND, cloneInventory.get(bowSlot));
        }
    }

    private void equipBestMelee() {
        int bestSlot = -1;
        double bestDamage = 1.0D;

        for (int i = 0; i < 36; i++) {
            ItemStack stack = cloneInventory.get(i);
            if (stack.isEmpty()) {
                continue;
            }

            Item item = stack.getItem();
            if (!(item instanceof ItemSword) && !(item instanceof ItemAxe)) {
                continue;
            }

            double damage = 0.0D;
            for (Map.Entry<String, AttributeModifier> entry : stack.getAttributeModifiers(EntityEquipmentSlot.MAINHAND).entries()) {
                if (SharedMonsterAttributes.ATTACK_DAMAGE.getName().equals(entry.getKey())) {
                    damage += entry.getValue().getAmount();
                }
            }

            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = i;
            }
        }

        if (bestSlot >= 0) {
            setItemStackToSlot(EntityEquipmentSlot.MAINHAND, cloneInventory.get(bestSlot));
        } else {
            setItemStackToSlot(EntityEquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
    }

    private int findItemSlot(Item item) {
        for (int i = 0; i < 41; i++) {
            if (!cloneInventory.get(i).isEmpty() && cloneInventory.get(i).getItem() == item) {
                return i;
            }
        }
        return -1;
    }

    private int findArrowSlot() {
        for (int i = 0; i < 41; i++) {
            ItemStack stack = cloneInventory.get(i);
            if (!stack.isEmpty() && stack.getItem() instanceof ItemArrow) {
                return -1 + i + 1;
            }
        }
        return -1;
    }

    @Override
    public boolean attackEntityAsMob(Entity entityIn) {
        float damage = getHeldAttackDamage();
        int knockback = 0;

        ItemStack held = getHeldItemMainhand();

        if (entityIn instanceof EntityLivingBase) {
            damage += EnchantmentHelper.getModifierForCreature(
                    held,
                    ((EntityLivingBase) entityIn).getCreatureAttribute()
            );
            knockback += EnchantmentHelper.getKnockbackModifier(this);
        }

        boolean flag = entityIn.attackEntityFrom(DamageSource.causeMobDamage(this), damage);

        if (flag) {
            if (knockback > 0 && entityIn instanceof EntityLivingBase) {
                ((EntityLivingBase) entityIn).knockBack(
                        this,
                        (float) knockback * 0.5F,
                        MathHelper.sin(this.rotationYaw * 0.017453292F),
                        -MathHelper.cos(this.rotationYaw * 0.017453292F)
                );
                this.motionX *= 0.6D;
                this.motionZ *= 0.6D;
            }

            int fireAspect = EnchantmentHelper.getFireAspectModifier(this);
            if (fireAspect > 0) {
                entityIn.setFire(fireAspect * 4);
            }

            applyEnchantments(this, entityIn);
            playSound(SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0F, 1.0F);
        }

        return flag;
    }

    @Override
    public void attackEntityWithRangedAttack(EntityLivingBase target, float distanceFactor) {
        int arrowSlot = findArrowSlot();
        int bowSlot = findItemSlot(Items.BOW);

        if (arrowSlot < 0 || bowSlot < 0) {
            return;
        }

        ItemStack arrowStack = cloneInventory.get(arrowSlot);
        ItemArrow itemarrow = (ItemArrow) arrowStack.getItem();
        EntityArrow entityarrow = itemarrow.createArrow(world, arrowStack, this);

        float charge = MathHelper.clamp(distanceFactor, 0.1F, 1.0F);

        double d0 = target.posX - posX;
        double d1 = target.getEntityBoundingBox().minY + (double) (target.height / 3.0F) - entityarrow.posY;
        double d2 = target.posZ - posZ;
        double d3 = MathHelper.sqrt(d0 * d0 + d2 * d2);

        entityarrow.shoot(d0, d1 + d3 * 0.2D, d2, charge * 3.0F, difficulty.getArrowInaccuracy());

        if (charge >= 1.0F) {
            entityarrow.setIsCritical(true);
        }

        world.spawnEntity(entityarrow);

        arrowStack.shrink(1);
        if (arrowStack.getCount() <= 0) {
            cloneInventory.set(arrowSlot, ItemStack.EMPTY);
        }

        playSound(SoundEvents.ENTITY_ARROW_SHOOT, 1.0F, 1.0F);
    }

    @Override
    public void setSwingingArms(boolean swingingArms) {
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (diggingInvulnerable) {
            return false;
        }

        if (amount >= getHealth() && tryUseTotem()) {
            return false;
        }

        return super.attackEntityFrom(source, amount);
    }

    private boolean tryUseTotem() {
        int slot = findItemSlot(Items.TOTEM_OF_UNDYING);
        if (slot < 0) {
            return false;
        }

        ItemStack stack = cloneInventory.get(slot);
        stack.shrink(1);
        if (stack.getCount() <= 0) {
            cloneInventory.set(slot, ItemStack.EMPTY);
        }

        setHealth(1.0F);
        clearActivePotions();
        addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 900, 1));
        addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 100, 1));
        addPotionEffect(new PotionEffect(MobEffects.FIRE_RESISTANCE, 800, 0));
        world.setEntityState(this, (byte) 35);
        return true;
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) {
            for (ItemStack stack : cloneInventory) {
                if (!stack.isEmpty()) {
                    entityDropItem(stack.copy(), 0.0F);
                }
            }
        }
        super.onDeath(cause);
    }

    @Override
    protected void dropEquipment(boolean wasRecentlyHit, int lootingModifier) {
    }

    @Override
    protected void updateAITasks() {
        super.updateAITasks();

        BlockPos front = new BlockPos(
                MathHelper.floor(this.posX + (double) (-MathHelper.sin(this.rotationYaw * 0.017453292F))),
                MathHelper.floor(this.getEntityBoundingBox().minY),
                MathHelper.floor(this.posZ + (double) (MathHelper.cos(this.rotationYaw * 0.017453292F)))
        );

        IBlockState state = world.getBlockState(front);
        if (state.getBlock() instanceof BlockDoor) {
            BlockDoor door = (BlockDoor) state.getBlock();
            if (state.getMaterial().isSolid() || door.isWood(world, front)) {
                this.world.destroyBlock(front, false);
            }
        }
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource damageSourceIn) {
        return SoundEvents.ENTITY_PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_PLAYER_DEATH;
    }

    @Override
    protected ResourceLocation getLootTable() {
        return null;
    }

    @Override
    public float getEyeHeight() {
        return 1.62F;
    }

    @Override
    public boolean canDespawn() {
        return false;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);

        compound.setString("CloneName", getCustomNameTag());
        compound.setString("SkinSource", getSkinSourceName());
        compound.setString("Mode", mode.name());
        compound.setString("Difficulty", difficulty.name());
        compound.setString("ControlledPlayer", controlledPlayerName);
        compound.setBoolean("PatrolToA", patrolToA);
        compound.setInteger("PatrolWaitTicks", patrolWaitTicks);
        compound.setBoolean("DigInvuln", diggingInvulnerable);
        compound.setInteger("ChaseGraceTicks", chaseGraceTicks);

        if (patrolA != null) {
            compound.setIntArray("PatrolA", new int[]{patrolA.getX(), patrolA.getY(), patrolA.getZ()});
        }
        if (patrolB != null) {
            compound.setIntArray("PatrolB", new int[]{patrolB.getX(), patrolB.getY(), patrolB.getZ()});
        }
        if (campPos != null) {
            compound.setIntArray("CampPos", new int[]{campPos.getX(), campPos.getY(), campPos.getZ()});
        }

        ItemStackHelper.saveAllItems(compound, cloneInventory);

        NBTTagList ignored = new NBTTagList();
        for (String name : ignoredPlayers) {
            ignored.appendTag(new NBTTagString(name));
        }
        compound.setTag("IgnoredPlayers", ignored);

        NBTTagList patrolTargets = new NBTTagList();
        for (String name : patrolAlertPlayers) {
            patrolTargets.appendTag(new NBTTagString(name));
        }
        compound.setTag("PatrolAlertPlayers", patrolTargets);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);

        setCloneName(compound.getString("CloneName"));
        setSkinSourceName(compound.getString("SkinSource"));

        mode = CloneMode.fromString(compound.getString("Mode"));
        if (mode == null) {
            mode = CloneMode.STAY;
        }

        difficulty = CloneDifficulty.fromString(compound.getString("Difficulty"));
        if (difficulty == null) {
            difficulty = CloneDifficulty.NORMAL;
        }

        controlledPlayerName = compound.getString("ControlledPlayer");
        patrolToA = compound.getBoolean("PatrolToA");
        patrolWaitTicks = compound.getInteger("PatrolWaitTicks");
        diggingInvulnerable = compound.getBoolean("DigInvuln");
        chaseGraceTicks = compound.getInteger("ChaseGraceTicks");

        if (compound.hasKey("PatrolA")) {
            int[] a = compound.getIntArray("PatrolA");
            patrolA = new BlockPos(a[0], a[1], a[2]);
        }

        if (compound.hasKey("PatrolB")) {
            int[] b = compound.getIntArray("PatrolB");
            patrolB = new BlockPos(b[0], b[1], b[2]);
        }

        if (compound.hasKey("CampPos")) {
            int[] c = compound.getIntArray("CampPos");
            campPos = new BlockPos(c[0], c[1], c[2]);
        }

        ItemStackHelper.loadAllItems(compound, cloneInventory);

        ignoredPlayers.clear();
        NBTTagList ignored = compound.getTagList("IgnoredPlayers", 8);
        for (int i = 0; i < ignored.tagCount(); i++) {
            ignoredPlayers.add(ignored.getStringTagAt(i));
        }

        patrolAlertPlayers.clear();
        NBTTagList patrolTargets = compound.getTagList("PatrolAlertPlayers", 8);
        for (int i = 0; i < patrolTargets.tagCount(); i++) {
            patrolAlertPlayers.add(patrolTargets.getStringTagAt(i));
        }

        syncEquipmentFromInventory();
        applyDifficultyStats();
    }

    @Override
    public int getSizeInventory() {
        return cloneInventory.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : cloneInventory) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getStackInSlot(int index) {
        return cloneInventory.get(index);
    }

    @Override
    public ItemStack decrStackSize(int index, int count) {
        return ItemStackHelper.getAndSplit(cloneInventory, index, count);
    }

    @Override
    public ItemStack removeStackFromSlot(int index) {
        return ItemStackHelper.getAndRemove(cloneInventory, index);
    }

    @Override
    public void setInventorySlotContents(int index, ItemStack stack) {
        cloneInventory.set(index, stack);
        syncEquipmentFromInventory();
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    @Override
    public void markDirty() {
        syncEquipmentFromInventory();
    }

    @Override
    public boolean isUsableByPlayer(EntityPlayer player) {
        return isEntityAlive() && player.getDistance(this) <= 64.0D;
    }

    @Override
    public void openInventory(EntityPlayer player) {
    }

    @Override
    public void closeInventory(EntityPlayer player) {
    }

    @Override
    public boolean isItemValidForSlot(int index, ItemStack stack) {
        return true;
    }

    @Override
    public int getField(int id) {
        return 0;
    }

    @Override
    public void setField(int id, int value) {
    }

    @Override
    public int getFieldCount() {
        return 0;
    }

    @Override
    public void clear() {
        for (int i = 0; i < cloneInventory.size(); i++) {
            cloneInventory.set(i, ItemStack.EMPTY);
        }
        syncEquipmentFromInventory();
    }

    @Override
    public String getName() {
        return hasCustomName() ? getCustomNameTag() : "Clone";
    }

    @Override
    public boolean hasCustomName() {
        return super.hasCustomName();
    }

    @Override
    public ITextComponent getDisplayName() {
        return new TextComponentString(getName());
    }
}