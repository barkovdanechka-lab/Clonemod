package com.example.cloneplayer;

import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.WorldServer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CloneUtils {
    public static List<EntityClonePlayer> getAllClones(MinecraftServer server) {
        List<EntityClonePlayer> result = new ArrayList<>();
        for (WorldServer world : server.worlds) {
            for (Entity entity : world.loadedEntityList) {
                if (entity instanceof EntityClonePlayer) {
                    result.add((EntityClonePlayer) entity);
                }
            }
        }
        return result;
    }

    public static EntityClonePlayer findClone(MinecraftServer server, String idOrName) {
        try {
            int id = Integer.parseInt(idOrName);
            for (WorldServer world : server.worlds) {
                Entity entity = world.getEntityByID(id);
                if (entity instanceof EntityClonePlayer) {
                    return (EntityClonePlayer) entity;
                }
            }
        } catch (NumberFormatException ignored) {
        }

        for (EntityClonePlayer clone : getAllClones(server)) {
            if (clone.getName().equalsIgnoreCase(idOrName) || clone.getCustomNameTag().equalsIgnoreCase(idOrName)) {
                return clone;
            }
        }

        return null;
    }

    public static EntityClonePlayer findCloneByUUID(MinecraftServer server, UUID uuid) {
        for (WorldServer world : server.worlds) {
            Entity entity = world.getEntityFromUuid(uuid);
            if (entity instanceof EntityClonePlayer) {
                return (EntityClonePlayer) entity;
            }
        }
        return null;
    }
}