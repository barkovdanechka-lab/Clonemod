package com.example.cloneplayer;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityClonePlayer.class, new IRenderFactory<EntityClonePlayer>() {
            @Override
            public RenderClonePlayer createRenderFor(RenderManager manager) {
                return new RenderClonePlayer(manager);
            }
        });

        ModelLoader.setCustomModelResourceLocation(
                ClonePlayerMod.CONTROL_STICK,
                0,
                new ModelResourceLocation(ClonePlayerMod.MODID + ":control_stick", "inventory")
        );
    }

    @Override
    public void init() {
    }
}