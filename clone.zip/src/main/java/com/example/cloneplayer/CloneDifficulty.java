package com.example.cloneplayer;

public enum CloneDifficulty {
    EASY(20, 30, 10, 1.00D, 0.23D),
    NORMAL(14, 22, 4, 1.10D, 0.26D),
    HARD(10, 16, 1, 1.30D, 0.30D);

    private final int meleeCooldown;
    private final int rangedCooldown;
    private final int arrowInaccuracy;
    private final double moveSpeed;
    private final double attributeSpeed;

    CloneDifficulty(int meleeCooldown, int rangedCooldown, int arrowInaccuracy, double moveSpeed, double attributeSpeed) {
        this.meleeCooldown = meleeCooldown;
        this.rangedCooldown = rangedCooldown;
        this.arrowInaccuracy = arrowInaccuracy;
        this.moveSpeed = moveSpeed;
        this.attributeSpeed = attributeSpeed;
    }

    public int getMeleeCooldown() {
        return meleeCooldown;
    }

    public int getRangedCooldown() {
        return rangedCooldown;
    }

    public int getArrowInaccuracy() {
        return arrowInaccuracy;
    }

    public double getMoveSpeed() {
        return moveSpeed;
    }

    public double getAttributeSpeed() {
        return attributeSpeed;
    }

    public static CloneDifficulty fromString(String s) {
        for (CloneDifficulty d : values()) {
            if (d.name().equalsIgnoreCase(s)) {
                return d;
            }
        }
        return null;
    }
}