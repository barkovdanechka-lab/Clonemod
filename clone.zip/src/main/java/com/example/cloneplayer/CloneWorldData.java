package com.example.cloneplayer;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;

import java.util.HashSet;
import java.util.Set;

public class CloneWorldData extends WorldSavedData {
    public static final String DATA_NAME = ClonePlayerMod.MODID + "_world_data";

    private final Set<String> globalIgnoredPlayers = new HashSet<>();

    public CloneWorldData() {
        super(DATA_NAME);
    }

    public CloneWorldData(String name) {
        super(name);
    }

    public static CloneWorldData get(World world) {
        MapStorage storage = world.getMapStorage();
        CloneWorldData data = (CloneWorldData) storage.getOrLoadData(CloneWorldData.class, DATA_NAME);
        if (data == null) {
            data = new CloneWorldData();
            storage.setData(DATA_NAME, data);
        }
        return data;
    }

    public boolean toggleGlobalIgnore(String name) {
        String key = name.toLowerCase();
        boolean added;
        if (globalIgnoredPlayers.contains(key)) {
            globalIgnoredPlayers.remove(key);
            added = false;
        } else {
            globalIgnoredPlayers.add(key);
            added = true;
        }
        markDirty();
        return added;
    }

    public boolean isGloballyIgnored(String name) {
        return globalIgnoredPlayers.contains(name.toLowerCase());
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        globalIgnoredPlayers.clear();
        NBTTagList list = nbt.getTagList("GlobalIgnores", 8);
        for (int i = 0; i < list.tagCount(); i++) {
            globalIgnoredPlayers.add(list.getStringTagAt(i));
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        NBTTagList list = new NBTTagList();
        for (String s : globalIgnoredPlayers) {
            list.appendTag(new NBTTagString(s));
        }
        compound.setTag("GlobalIgnores", list);
        return compound;
    }
}