package com.example.cloneplayer;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ItemControlStick extends Item {
    private static class Selection {
        UUID cloneId;
        BlockPos firstPatrolPoint;
    }

    private static final Map<UUID, Selection> SELECTIONS = new HashMap<UUID, Selection>();

    public ItemControlStick() {
        setMaxStackSize(1);
    }

    private boolean isAdmin(EntityPlayer player) {
        return player != null && player.canUseCommand(2, ClonePlayerMod.MODID);
    }

    @Override
    public boolean itemInteractionForEntity(ItemStack stack, EntityPlayer player, EntityLivingBase target, EnumHand hand) {
        if (player.world.isRemote || !(target instanceof EntityClonePlayer) || !isAdmin(player)) {
            return false;
        }

        EntityClonePlayer clone = (EntityClonePlayer) target;
        Selection sel = SELECTIONS.get(player.getUniqueID());
        if (sel == null) {
            sel = new Selection();
            SELECTIONS.put(player.getUniqueID(), sel);
        }

        sel.cloneId = clone.getUniqueID();
        sel.firstPatrolPoint = null;

        player.sendStatusMessage(new TextComponentString(
                "\u0412\u044B\u0431\u0440\u0430\u043D \u043A\u043B\u043E\u043D: " + clone.getName() +
                        " [id=" + clone.getEntityId() + "], \u0440\u0435\u0436\u0438\u043C: " + clone.getMode()
        ), false);

        return true;
    }

    @Override
    public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos, EnumHand hand, EnumFacing facing,
                                      float hitX, float hitY, float hitZ) {
        if (world.isRemote || !isAdmin(player)) {
            return EnumActionResult.FAIL;
        }

        Selection sel = SELECTIONS.get(player.getUniqueID());
        if (sel == null || sel.cloneId == null) {
            player.sendStatusMessage(new TextComponentString(
                    "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043D\u0430\u0436\u043C\u0438 \u041F\u041A\u041C \u043F\u043E \u043A\u043B\u043E\u043D\u0443."
            ), false);
            return EnumActionResult.FAIL;
        }

        MinecraftServer server = world.getMinecraftServer();
        if (server == null) {
            return EnumActionResult.FAIL;
        }

        EntityClonePlayer clone = CloneUtils.findCloneByUUID(server, sel.cloneId);
        if (clone == null) {
            player.sendStatusMessage(new TextComponentString(
                    "\u041A\u043B\u043E\u043D \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D."
            ), false);
            return EnumActionResult.FAIL;
        }

        if (clone.getMode() == CloneMode.PATROL) {
            if (sel.firstPatrolPoint == null) {
                sel.firstPatrolPoint = pos.toImmutable();
                player.sendStatusMessage(new TextComponentString(
                        "\u0422\u043E\u0447\u043A\u0430 A \u043F\u0430\u0442\u0440\u0443\u043B\u044F: " + pos
                ), false);
            } else {
                clone.setPatrolPoints(sel.firstPatrolPoint, pos.toImmutable());
                player.sendStatusMessage(new TextComponentString(
                        "\u0422\u043E\u0447\u043A\u0430 B \u043F\u0430\u0442\u0440\u0443\u043B\u044F: " + pos
                ), false);
                player.sendStatusMessage(new TextComponentString(
                        "\u041F\u0430\u0442\u0440\u0443\u043B\u044C \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D."
                ), false);
                sel.firstPatrolPoint = null;
            }
            return EnumActionResult.SUCCESS;
        }

        if (clone.getMode() == CloneMode.CAMP) {
            clone.setCampPosition(pos.toImmutable());
            player.sendStatusMessage(new TextComponentString(
                    "\u0422\u043E\u0447\u043A\u0430 \u043A\u0435\u043C\u043F\u0430: " + pos
            ), false);
            return EnumActionResult.SUCCESS;
        }

        player.sendStatusMessage(new TextComponentString(
                "\u0423 \u043A\u043B\u043E\u043D\u0430 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0440\u0435\u0436\u0438\u043C PATROL \u0438\u043B\u0438 CAMP \u0447\u0435\u0440\u0435\u0437 /clonecon"
        ), false);
        return EnumActionResult.FAIL;
    }
}